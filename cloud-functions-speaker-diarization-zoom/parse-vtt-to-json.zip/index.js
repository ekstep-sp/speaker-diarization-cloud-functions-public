/**
 * Responds to any HTTP request.
 *
 * @param {!express:Request} req HTTP request context.
 * @param {!express:Response} res HTTP response context.
 */

function isSequencePresent(objectToFind, sourceObjectArray) {
    const indexIfPresent = sourceObjectArray.findIndex(objectData => {
        return (objectData.start === objectToFind.start && objectData.end === objectToFind.end)
    });
    return indexIfPresent;
}

function wordsArrayCleaner(sequenceObject) {
    let invalidWordIndex = -1;
    let cleanedWordsArray = sequenceObject.words.filter((word, index) => {
        if (word.word === '') {
            invalidWordIndex = index;
            return false;
        } else if (invalidWordIndex !== -1 && index > invalidWordIndex) {
            // discard all the words after the '' word
            return false;
        } else {
            // it is a valid word
            return true;
        }
    });
    // extract all the words
    return cleanedWordsArray.map(wordObj => wordObj.word);
}


function processVTTtoJSON(dataToProcess) {
    if (dataToProcess instanceof Object) {
        const JSONData = []
        // iterate for each array object,
        // create a new object with same start and end time, and store the words array as string by discarding the empty entry and entries thereafter
        //  if an object with same start and end time occurs, follow step 2 and append in the saved entry of same start and end time
        dataToProcess.forEach(sequenceObject => {
            let isPresent = isSequencePresent(sequenceObject, JSONData);
            if (isPresent !== -1) {
                // the sequence is already present, append the words in that sequence
                let newTranscribedTextArray = wordsArrayCleaner(sequenceObject);
                // join the new filtered words in a sentence and store it in the sequence object
                const newTranscribedTextString = newTranscribedTextArray.join(' ');
                JSONData[isPresent]['transcribed_text'] += newTranscribedTextString;
            } else {
                // it is a new sequence, convert the words into sentence and push it
                let newTranscribedTextArray = wordsArrayCleaner(sequenceObject);
                // join the new filtered words in a sentence and store it in the sequence object
                const newTranscribedTextString = newTranscribedTextArray.join(' ');

                JSONData.push({
                    start: sequenceObject.start,
                    startSeconds: (parseFloat(sequenceObject.start) / 1000),
                    end: sequenceObject.end,
                    endSeconds: (parseFloat(sequenceObject.end) / 1000),
                    transcribed_text: newTranscribedTextString
                });
            }
        });
        return JSONData;
    } else {
        console.log('invalid file structure provided');
        return null;
    }
}

exports.initiate = (req, res) => {
 	console.log('inside parse function');
  	console.log(req.body);
	const bodyData = req.body;
    const processedData = processVTTtoJSON(bodyData);
  	
  if (processedData) {
    // sending back data in json format
  res.status(200).send(JSON.stringify({status: 200, data: processedData}));
  }
  else {
    res.status(400).send({status: 400, error: 'Error while converting vtt to json'});
  }
};
