/**
 * Responds to any HTTP request.
 *
 * @param {!express:Request} req HTTP request context.
 * @param {!express:Response} res HTTP response context.
 */
const request = require('request');
const vttConvertor = require('vtt-to-json');

function sendDataCompletely(data, meetingDetails, responseObject) {
	
  console.log('called sending data to merge-meeting-files-lambda');
  // add meeting details into the object as well
  const reqBody = {};
  
  reqBody['details'] = meetingDetails;
  reqBody['data'] = data;
  console.log('sending request to vis db', reqBody);
  request.post({
  	url: '<public-url-of-merge-meeting-files-cloud-function>',
    headers: {'content-type': 'application/json'},
    body: JSON.stringify(reqBody)
  }, (err, res, body) => {
  		// recieved merged file data
    console.log('recieved merged file data, sending it back');
    const finalData = JSON.parse(body);
    const responseObj = {
    status: finalData.status, message: finalData.message, details: finalData.details, data: finalData.data};
    responseObject.status(200).send(responseObj);
  });
}


exports.getmeetingFiles = (req, res) => {
  const ALLOWED_FILES_TYPE = ['TIMELINE', 'TRANSCRIPT'];
  // read the body, check if there is a timeline file and transcribe file, record their urls and fetch the files, store the files and send it to
  // an api which will combine those files into a single json
	console.log(req.body);
  	const meetingDetails = {
    	video_name: req.body.topic || '',
    };
  console.log('meeting details captured are ', meetingDetails);
  if (req.body.hasOwnProperty('recording_files') && Array.isArray(req.body.recording_files)) {
  	// get the timeline and transcribe files
	const returnDataArray = [];
    let completedRequests = 0;
    let requestCounter = 0;
    req.body.recording_files.forEach(fileObject => {
    	if (fileObject.hasOwnProperty('file_type') && ALLOWED_FILES_TYPE.includes(fileObject.file_type)) {
          requestCounter += 1;
          
        	console.log('file type ', fileObject.file_type + ' detected');
          	request(fileObject.download_url, (error, response, body) => {
            	if (response && !error) {
            		console.log('recieved response', body);
                  if (fileObject.file_type === 'TIMELINE') {
                  fileObject['file_recorded_data'] = JSON.parse(body);
                    returnDataArray.push(fileObject);
                     // increment the counter
              	 	completedRequests += 1;
              	 	if (completedRequests === requestCounter) {
                     	sendDataCompletely(returnDataArray, meetingDetails, res);
              			}
                  } else {
                    
                    vttConvertor(body).then(convertedVtt => {
                    fileObject['file_recorded_data'] = convertedVtt;
                      
                      returnDataArray.push(fileObject);
                      
                       // increment the counter
              	 completedRequests += 1;
              	 if (completedRequests === requestCounter) {
                     sendDataCompletely(returnDataArray, meetingDetails, res);
              		}
                    });
                  }
            	} else if (error) {
            		console.log('an error recorded', error);
                  res.status(500).send({status: 500, message: error});
            	}
            });
        }
    });
  }
};
