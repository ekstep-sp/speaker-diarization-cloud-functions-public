const request = require('request');

exports.initiate = (req, res) => {
    // this function will trigger everytime webhook sends the data whenever a recording is properly finished
  	const ZOOM_VIDEO_URL = '<public-url-of-get_zoom_videos-cloud-function>';
  	const JWT_TOKEN_URL = '<public-url-of-get_jwt_auth_token-cloud-function>';
    
  	var READ_ZOOM_MEETING_URL = (meetingID) => {
    	console.log('meeting id recieved to create url is ', meetingID);
     	return `https://api.zoom.us/v2/meetings/${meetingID}/recordings`;
    	};
  
  
        let bodyData = req.body;
  		console.log('body data is ', bodyData);
        if (bodyData.hasOwnProperty('event') && bodyData.event === 'recording.transcript_completed') {
            console.log('RECORDING COMPLETED WEBHOOK INITIATED');
           res.status(200).send('recieved body successfully and sent data forward, refer cloud logs from here');

          // get the uuid of the meeting and fetch it using the get meeting details api of zoom, send its response to the getZoomVideos function
             if (bodyData.hasOwnProperty('payload') && bodyData.payload.hasOwnProperty('object')) {
               // get the token for accessing the get meeting api
               request.get(JWT_TOKEN_URL, (tokenErr, tokenRes, tokenBody) => {
               		if (tokenErr) {
                    	console.log('did not recieve a good quality token, check the token generator function, ABORT');
                      	// res.status(200).send('recieved body successfully but was not able to generate a good token');
                    }
                 	else if (!tokenErr && tokenBody) {
                      	let parsedTokenBody = JSON.parse(tokenBody);
                      	let tokenToUse = parsedTokenBody.jwtToken;
                      	console.log('token recieved is ', tokenToUse);
                      	// get the meeting id
                      	const meetingGetUrl = READ_ZOOM_MEETING_URL(bodyData.payload.object.uuid);
                      	
                      	getMeetingDetails(tokenToUse, meetingGetUrl)
                          .then(response => {
                        		console.log('recieved response from meeting id in the main code', response);
                          		let meetingResBodyParsed;
                          		if (typeof response === 'string') {
                                	console.log('recieved body as string, going to parse');
                                  	meetingResBodyParsed = JSON.parse(response);
                                }
                          		else if (typeof response === 'object') {
                                	console.log('recieved body as object, going as it is');
                                  	meetingResBodyParsed = {...response};
                                }
                          	// send this data as payload to the getZoomVideos cloud function
                          	   request.post({
              						url: ZOOM_VIDEO_URL,
                					headers: {'content-type': 'application/json'},
               						body: JSON.stringify(meetingResBodyParsed)
             					}, (err, getZoomRes, getZoomBody) => {
             						if (err && !getZoomRes) {
               						console.log('recieved error from getZoom cloud function ', err);
              						}
              						else if (!err && getZoomBody) {
                						console.log('recieved response from getZoomVideos cloud function ', getZoomBody);
             						}
              						// no need to record anything, its been already logged properly
                                    // res.status(200).send('recieved body successfully and sent data forward, refer cloud logs from here');
             					});

                        	})
                          .catch(meetingErr => {
                        		console.log('An error occured while getting the meeting details', meetingErr);
                          		// res.status(200).send('recieved body successfully but got an error while reading meeting details, refer cloud logs');
                        	});
                    }
               });
             }
            else {
                console.log('did not find either payload or payload.object key in the body');
                res.status(200).send('Webhook recieved the body successfully but the body does not contain payload or payload.object key to process!');
            }
        } else {
            console.log('event recieved is not of recording.completed');
            res.status(200).send('Webhook recieved the body successfully but the event key of body is "not recording.completed" !');
        }
  };

function getMeetingDetails(jwtToken, urlToHit) {
  return new Promise((resolve, reject) => {
  // hit the api, if success, resolve else reject
    console.log('url to hit is ', urlToHit);
    console.log('token to use is ', jwtToken);
  request.get({
  	url: urlToHit,
    headers: {'content-type': 'application/json', 'Authorization': `Bearer ${jwtToken}`}
  }, (err, res, body) => {
    console.log('recieved get meeting response ');
    console.log('err --->', err);
    console.log('res --->', res);
    console.log('body --->', body);
  	if (!err && body) {
    	console.log('detected body', body);
      	resolve(body);
    } else if (err) {
    	console.log('detected error ', err);
      	reject(null);
    } else {
    	console.log('catched something unusual ');
      	console.log('err --->', err);
    	console.log('res --->', res);
    	console.log('body --->', body);
      reject(null);
    }
  
  });
  });
}
    