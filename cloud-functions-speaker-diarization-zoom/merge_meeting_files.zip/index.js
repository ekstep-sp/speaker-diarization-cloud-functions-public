/**
 * Responds to any HTTP request.
 *
 * @param {!express:Request} req HTTP request context.
 * @param {!express:Response} res HTTP response context.
 */

function parseTS(dataToUse) {
    const newParsedTSData = dataToUse.timeline.map(timelineObject => {
        // read the ts key and assign a new key names time_stamp which stores js readable timestamp
        let objTS = timelineObject.ts || null;
        if (objTS) {
            let objTSArr = objTS.split(':');
            if (objTSArr.length === 3) {
                // pick the seconds portion, and set a round off seconds value
                let fetchedHours = objTSArr[0] !== '00' ? parseFloat(objTSArr[0]) : null;
                let fetchedMinutes = objTSArr[1] !== '00' ? parseFloat(objTSArr[1]) : null;
                let fetchedSeconds = parseFloat(objTSArr[2]);

                if (fetchedHours !== null) {
                    fetchedHours = fetchedHours * 60 * 60;
                }
                if (fetchedMinutes !== null) {
                    fetchedMinutes = fetchedMinutes * 60;
                }
                const totalTSinSecs = fetchedHours + fetchedMinutes + fetchedSeconds;
                return {
                    ...timelineObject,
                    parsedTS: totalTSinSecs
                }
            }
        } else return timelineObject;
    });
    return newParsedTSData;
}

function mergeFiles(sourceData, destData) {
    // the function will merge the common properties of sourceData into the destData, base will be destData
    const timelineArray = sourceData;
    const transcriptArray = destData;

  console.log(timelineArray);
  console.log(transcriptArray);
    // for each transcript entry, pick the start and endtime
    // check the number of entries in timeline data which come under the above time range
    // if there is one speaker in list of objects in timeline array for the above range, assign the name to the transcript entry
    // else find which user's entry is more than 5 in this sequece , and assign it in the transcript object

    transcriptArray.forEach(transcriptObject => {
        const transcriptRange = {
            start: transcriptObject.startSeconds,
            end: transcriptObject.endSeconds,
            range: transcriptObject.endSeconds - transcriptObject.startSeconds
        }

        const speakerObject = {}
        timelineArray.forEach((timelineObject, timelineObjectIndex) => {
            if (timelineObject.parsedTS >= transcriptRange.start && timelineObject.parsedTS <= transcriptRange.end) {
                // save the speaker name and its count
                if (timelineObject.users.length) {
                    if (speakerObject.hasOwnProperty(timelineObject.users[0].username.split(' ').join('_'))) {
                        // speaker name is already present, just increment the count
                        speakerObject[timelineObject.users[0].username.split(' ').join('_')].occurance_count += 1;
                    } else {
                        //  new speaker entry
                        speakerObject[timelineObject.users[0].username.split(' ').join('_')] = {
                            email: timelineObject.users[0].email_address,
                            occurance_count: 1
                        }
                    }
                }
            }
        });
        // if there is only one speaker in the range, simply use the name
        if (Object.keys(speakerObject).length === 1) {
            transcriptObject['speakerTag'] = Object.keys(speakerObject)[0];
        }
    });
    return transcriptArray;
}

exports.initiateMerge = (req, res) => {
  console.log('recieved data, processing started');
  const VIS_DB_URL = '<your-backend-domain>/zoom-to-vis/visualize';
  let bodyData = req.body;
  let dataArr = req.body.data;
  let meetingDetails = req.body.details;
  console.log(dataArr);
  console.log(meetingDetails);
  if (dataArr.length > 0) {
	let transcriptData;
	let timelineData;
	dataArr.forEach(dataObj => {
		if (dataObj.file_type === 'TRANSCRIPT') {
			transcriptData = dataObj.file_recorded_data;
		} else if (dataObj.file_type === 'TIMELINE') {
			timelineData = dataObj.file_recorded_data;
		}
	});
    require('request').post(
      {
		url: '<public-url-of-parse-vtt-to-json-cloud-function>',
      	headers: {
               		'content-type': 'application/json'
                },
        body: JSON.stringify(transcriptData)               
      }, (err,parseVttRes,body) => {
        console.log('body recieved is ', body);
        const responseBody = JSON.parse(body);
        console.log('keys present in body ', Object.entries(responseBody));
        console.log(responseBody.hasOwnProperty('status'), responseBody.hasOwnProperty('data'));
        console.log(responseBody.status === 200);
             if (err) {
             	console.log('An error occured while calling parse-vtt-to-json function', err);
               res.status(500).send({status: 500, error: 'An error occured while calling parse-vtt-to-json function'})
             }

             else if (responseBody.hasOwnProperty('status') && responseBody.status === 200) {
             	console.log('recieved respose from vtt-to-json function', responseBody['data']); 
                const processedVTT2JSONData = responseBody['data'];
                if (processedVTT2JSONData !== null) {
                    // the vtt data is converted to json successfully, time to combine
                    console.log('VTT 2 JSON converted successfully, poceeding to join data');
                    if (!!timelineData && timelineData instanceof Object && timelineData !== null) {
                        console.log('timeline data is extracted properly, initiating merge');
                        const timelineDataWithNewTS = parseTS(timelineData);
                        console.log('calling mergeFiles');
                      console.log('timelineData', timelineDataWithNewTS);
                      console.log('parsedData ', processedVTT2JSONData);
                        const finalMergedData = mergeFiles(timelineDataWithNewTS, processedVTT2JSONData);
                        if (!!finalMergedData && finalMergedData instanceof Object) {
                            console.log('files merged successfully');
                            // add the meeting data to the finalData before sending
                          	const dataObjectToSend = {status: 200, message: 'files merged successfully', details: meetingDetails, data: finalMergedData};
                          console.log('sending data to vis_db api as ', dataObjectToSend);
                          require('request').post(
                            {
                            	url: VIS_DB_URL,
                                headers: {
               						'content-type': 'application/json'
                				},
        						body: JSON.stringify({...dataObjectToSend}) 
                            },  (err,VisRes,Visbody) => {
                              		console.log(typeof Visbody);
                              	let finalResponse = Visbody;
                              	console.log('finalResponse ', finalResponse);
                              	finalResponse = finalResponse.split('').join('');
                              	const parsedData = JSON.parse(finalResponse);
                              		if (err) {
                                    	console.log('captured error while recieving data from VIS API', err);
                                      	res.status(500).send({status: 500, error: 'An unexpected error occured while sending combined data to visualizer api'});
                                    }
                              		else if (parsedData.hasOwnProperty('status') && parsedData.status === 200) {
                                      console.log('recieved successful response from VIS API', parsedData);
                                    	res.status(200).send({status: 200, message: parsedData.message});
                                    } else {
                                      console.log('something unexpected from VIS API', Visbody);
                                    	res.status(Visbody.status).send({status: Visbody.status, error: Visbody['error'], message: Visbody['message']});
                                    }
                            	}
                          )
                          	// res.status(200).send({status: 200, message: 'files merged successfully', details: meetingDetails, data: finalMergedData});
                        } else {
                            console.log('could complete merging process, abort');
                          	res.status(500).send({status: 500, error: 'could not complete merging process'});
                        }
                    }
                } else {
                    console.log('unable to execute processVTT2JSON, aborting');
                  	res.status(500).send({status: 500, error: 'unable to convert vtt to json'});
                }
            } else {
                console.log('did not recieve any data array');
              	res.status(500).send({status: 500, error: 'did not recieve any data array'});
            }
		});
	}
};
